package com.kadam.foodhub.service;

import java.util.List;

import com.kadam.foodhub.entity.Items;

public interface ItemService {

	List<Items> findAllItems();

	List<Items> findAllItemsByUser(Long id);

	Items save(Items item);

	Items findItem(Long parseLong);

	void delete(Long parseLong);
}
