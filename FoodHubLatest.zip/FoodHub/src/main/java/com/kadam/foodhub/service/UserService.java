package com.kadam.foodhub.service;

import java.util.List;

import com.kadam.foodhub.dto.UserDto;
import com.kadam.foodhub.entity.User;

public interface UserService {
    void saveUser(UserDto userDto);

    User findByEmail(String email);

    List<UserDto> findAllUsers();

	void delete(Long id);
}
