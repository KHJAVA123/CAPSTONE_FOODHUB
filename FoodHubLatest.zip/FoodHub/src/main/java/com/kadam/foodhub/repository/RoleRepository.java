package com.kadam.foodhub.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kadam.foodhub.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Role findByName(String name);
}
