package com.kadam.foodhub.controller;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.kadam.foodhub.entity.Items;
import com.kadam.foodhub.service.ItemService;
import com.kadam.foodhub.service.UserService;

import jakarta.validation.Valid;

@Controller
public class ItemsController {

	public ItemService itemService;
	public UserService userService;
	private User user = null;

	public ItemsController(ItemService itemService, UserService userService) {
		this.itemService = itemService;
		this.userService = userService;
	}

	@GetMapping("/items")
	public String listRegisteredUsers(Model model) {
		user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		com.kadam.foodhub.entity.User existing = userService.findByEmail(user.getUsername());

		model.addAttribute("items", itemService.findAllItemsByUser(existing.getId()));
		return "items";
	}

	@PostMapping("/saveItem")
	public String saveItem(@Valid @ModelAttribute("item") Items item, BindingResult result, Model model) {
		item.setUser(userService.findByEmail(user.getUsername()).getId());
		itemService.save(item);
		return "redirect:/items";
	}

	@GetMapping("/addItem")
	public String showRegistrationForm(Model model) {
		model.addAttribute("item", new Items());
		return "saveItem";
	}

	@GetMapping("/updateItem/{id}")
	public String update(Model model, @PathVariable String id) {
		model.addAttribute("item", itemService.findItem(Long.parseLong(id)));
		return "updateItem";
	}

	@GetMapping("/viewItem/{id}")
	public String viewItem(Model model, @PathVariable String id) {
		Items item = itemService.findItem(Long.parseLong(id));
		if (item.getImage() == null)
			item.setImage("/images/random.jpg");
		model.addAttribute("item", item);
		return "viewItem";
	}

	@PostMapping("/update")
	public String updateItem(@Valid @ModelAttribute("item") Items item, BindingResult result, Model model) {
		item.setUser(userService.findByEmail(user.getUsername()).getId());
		itemService.save(item);
		return "redirect:/items";
	}

	@GetMapping("/deleteItem/{id}")
	public String delete(Model model, @PathVariable String id) {
		itemService.delete(Long.parseLong(id));
		return "redirect:/items";
	}
}