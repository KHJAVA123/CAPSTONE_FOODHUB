package com.kadam.foodhub.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.kadam.foodhub.dto.UserDto;
import com.kadam.foodhub.entity.Role;
import com.kadam.foodhub.entity.User;
import com.kadam.foodhub.repository.RoleRepository;
import com.kadam.foodhub.repository.UserRepository;
import com.kadam.foodhub.service.UserService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	public UserServiceImpl(UserRepository userRepository, RoleRepository roleRepository,
			PasswordEncoder passwordEncoder) {
		this.userRepository = userRepository;
		this.roleRepository = roleRepository;
		this.passwordEncoder = passwordEncoder;
	}

	@Override
	public void saveUser(UserDto userDto) {
		User user = new User();
		user.setName(userDto.getFirstName() + " " + userDto.getLastName());
		user.setEmail(userDto.getEmail());

		// encrypt the password once we integrate spring security
		// user.setPassword(userDto.getPassword());
		user.setPassword(passwordEncoder.encode(userDto.getPassword()));

		int size = userRepository.findAll().stream().filter(current -> {
			for (Role r : current.getRoles()) {
				return r.getName().equals("ROLE_ADMIN");
			}
			return false;
		}).collect(Collectors.toList()).size();

		Role role = null;
		if (size == 0) {
			role = roleRepository.findByName("ROLE_ADMIN");
			if (role == null) {
				role = checkRoleExist("ROLE_ADMIN");
			}
		} else {
			role = roleRepository.findByName("ROLE_USER");
			if (role == null) {
				role = checkRoleExist("ROLE_USER");
			}
		}

		user.setRoles(Arrays.asList(role));
		userRepository.save(user);
	}

	@Override
	public User findByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	@Override
	public List<UserDto> findAllUsers() {
		List<User> users = userRepository.findAll();
		List<User> usersToDisplay = new ArrayList<>();

		for (User u : users) {
			if (!u.getRoles().get(0).getName().equals("ROLE_ADMIN")) {
				usersToDisplay.add(u);
			}
		}

		return usersToDisplay.stream().map((user) -> convertEntityToDto(user)).collect(Collectors.toList());
	}

	private UserDto convertEntityToDto(User user) {
		UserDto userDto = new UserDto();
		String[] name = user.getName().split(" ");
		userDto.setFirstName(name[0]);
		userDto.setLastName(name[1]);
		userDto.setEmail(user.getEmail());
		userDto.setId(user.getId());
		return userDto;
	}

	private Role checkRoleExist(String roleName) {
		Role role = new Role();
		role.setName(roleName);
		return roleRepository.save(role);
	}

	@Override
	public void delete(Long id) {
		userRepository.deleteById(id);
	}
}
