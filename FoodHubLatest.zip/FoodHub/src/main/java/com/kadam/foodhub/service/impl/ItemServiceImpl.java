package com.kadam.foodhub.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kadam.foodhub.entity.Items;
import com.kadam.foodhub.repository.ItemsRepository;
import com.kadam.foodhub.service.ItemService;

@Service
public class ItemServiceImpl implements ItemService {

	@Autowired
	ItemsRepository repository;

	@Override
	public List<Items> findAllItems() {
		return repository.findAll();
	}

	@Override
	public List<Items> findAllItemsByUser(Long id) {
		List<Items> combined = repository.findByUserIsNull();
		combined.addAll(repository.findByUser(id));
		return combined;
	}

	@Override
	public Items save(Items item) {
		return repository.save(item);
	}

	@Override
	public Items findItem(Long id) {
		return repository.findById(id).get();
	}

	@Override
	public void delete(Long id) {
		repository.deleteById(id);
	}

}
